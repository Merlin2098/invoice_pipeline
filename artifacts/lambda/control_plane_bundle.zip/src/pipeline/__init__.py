"""Pipeline utilities."""
